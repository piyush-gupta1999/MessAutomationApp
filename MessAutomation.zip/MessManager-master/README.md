# MessManager

Mess!! Time to make it a little less messy! You are required to build a mess management
system for better interaction between management and the students.

Features:
1. Two different portals for management and students.
2. Mess managers can upload the next day's menu for all three meals.
3. Students can register themselves for whichever meals they want to have.
4. A unique QR code would be generated upon regitsration and the attendance would be taken upon by scanning of QR code generated.
5. Facility for both the managers and student to see there monthly expenses.
6. Add a complaint or suggestion regarding any mess activity.
7. Feedback can be given on any meal with ratings.
8. The managers should be able to view each students activity.

## Contibutors
* [Prajjwal Yadav](https://github.com/prajjyadav)
* [Prashanjeet](https://github.com/prashyadav)
* [Shravan Kumar Sahani](https://github.com/Shravankumarsahani)

